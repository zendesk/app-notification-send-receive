# App Notifications Example - Send

Demonstration of how to *send* a notification event within a Zendesk ticket sidebar app.

Please submit bug reports to [Insert Link](). Pull requests are welcome.
